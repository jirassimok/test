Just call one of the interactive functions in this file to complete
the corresponding thing using `ivy'.

Currently available: Elisp symbols, Clojure symbols, Git files.
