Minor mode providing highlighting of identifiers based on their
names. Each identifier gets a color based on a hash of its name.

Use `rainbow-identifiers-mode' to enable/disable.

Default colors try to be reasonable, but they can be changed by
changing the faces `rainbow-identifiers-identifier-<number>'.
