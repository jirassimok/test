Collection of useful combinators for Emacs Lisp

See documentation on https://github.com/magnars/dash.el#functions
