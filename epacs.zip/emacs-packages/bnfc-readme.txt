bnfc-mode simplifies editing BNFC input files in Emacs.  BNFC is a
handy tool for converting context-free grammars into parsers,
syntax highlighters, and documentation.
