This package provides the `hydra-ivy/body' command, which is a
quasi-prefix map, with many useful bindings.  These bindings are
shorter than usual, using mostly unprefixed keys.
