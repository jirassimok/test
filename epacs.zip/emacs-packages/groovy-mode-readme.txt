 This mode was initially developed using the Java and Awk modes that are part of CC Mode (the 5.31 source
 was used) and C# Mode from Dylan R. E. Moonfire <contact@mfgames.com> (the 0.5.0 source was used).  This
 code may contain some code fragments from those sources that was cut-and-pasted then edited.  All other
 code was newly entered by the author.  Obviously changes have been made since then.

 NB  This mode requires CC Mode 5.31 or later for the virtual semicolon code to work.

 There appears to be a problem in CC Mode 5.31 such that csharp-mode and groovy-mode crash XEmacs 21.4 if
 the files are byte compiled.
