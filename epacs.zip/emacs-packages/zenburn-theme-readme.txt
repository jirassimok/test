A port of the popular Vim theme Zenburn for Emacs 24, built on top
of the new built-in theme support in Emacs 24.
