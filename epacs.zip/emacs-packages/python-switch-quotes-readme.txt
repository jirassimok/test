  Converts strings like 'this' to strings like "this".
  Supports raw strings, docstrings and strings with escaped quotes.
