A dark color theme for Emacs 24+ (using deftheme), inspired by the
default dark theme in Light Table 0.4.0. This color theme is based
off the definitions and format in sellout's awesome
emacs-color-theme-solarized, providing support for a lot of modes.

This is still pretty rough around the edges; I think some color
tweaks are still needed, and pull requests are definitely welcome.
