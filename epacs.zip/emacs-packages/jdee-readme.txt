This file bootstraps JDEE.
