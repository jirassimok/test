Rainbow-blocks highlights blocks made of parentheses, brackets, and
braces according to their depth. Each successive level is
highlighted in a different color. This makes it easy to orient
yourself in the code, and tell which statements are at a given
level.
