Provides one auto-complete source for Scheme projects using geiser.
