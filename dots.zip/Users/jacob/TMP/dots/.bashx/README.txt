
File: .bashx/README
Author: Jacob Komissar
Date: 2016-03-22
Updated: 2016-10-26

bashx - Additional bash configuration.

This directory contains these files:
  Access files:
      README - this file
      alternatives/ - Other versions of files in this directory.
      Outdated/ - Obsolete files from this directory.
      bash_profile.alias   - an OS X alias to ~/.bash_profile
      bash_profile.symlink - a symbolic link to ~/.bash_profile
  Main files:
      load
      profile
      sources
      xguard
  Source files:
      bash_aliases
      bash_dir
      bash_extension
      bash_justforfun
	  bash_manpages
      bash_overrides
      bash_ps1
      bash_shortcuts
  Additional files:
      notes
      go


bashx reserves environment variable names starting with "BASHX_" for internal
use. The variable BASHX_TMP and all variables starting with BASHX_TMP_ are
additionally reserved for use within scripts, and may be changed at any time by
any bashx function or script. After use, such variables should be unset.


-------- Detailed File Descriptions --------

In the descriptions of the other files, filenames are referenced in ALL CAPS.

load - This file sources the other main files.
       This file should not need to be edited, except to change the sourcing
       conditions.

profile - This file contains setup, and is only sourced by default at startup.
          Setting of global variables should occur in this file.

sources - This file should contain the other files in this directory that LOAD
          should source. This file should only be sourced via LOAD.

xguard - Prevents excessive sourcing of the files in SOURCES. If a file
         sourced in SOURCES has not been modified since it was last sourced,
         xguard will keep it from being sourced. Removing this file will remove
         its benefits and detriments, but will not impede the sourcing process.
         This file should only be sourced via LOAD.

bash_aliases - This file contains aliases I have defined. The current aliases
               are py, py2, py3, ipy, ipy2, ipy3, la, e, E, el, El, roulette,
               and karabiner.

bash_dir - This is an example file for my folder-specific options. To
           demonstrate it, use the command "shortcuts" (from BASH_SHORTCUTS)
           while in this directory.

bash_extension - This file contains functions I have defined to extend bash
                 functionality. Current functions are no, lvars, battery, vm,
                 mkcd, and ts.

bash_justforfun - This file impedes basic bash functionality. Never source it,
                  and if you do, make sure you do so *after* anything else you
                  want to source. Currently, it impedes the use of yes, alias,
                  and type.

bash_overrides - This file contains functions that override functions already
                 present in bash. Most of these functions are named [function]2,
                 and are aliased to the original function immediately after
                 being defined. At this time, it overrides the following
                 commands:
                 - help; to provide information about the other changes
                 - bind; to prevent changing shell settings
                 - diff; to allow easy brief diffs
                 - emacs; to run emacs in the terminal by default
				 - man; to use BASH_MANPAGES functionality
                 - source; to allow more convenient use of bashx
                 - srm; to encourage care in its use
                 - tmux; to create shortcuts for certain options
				 - 

bash_ps1 - Contains a function to modify the bash prompt. After sourcing this
           file, use ps1 -h to display the help for this function.

bash_manpages - Contains various functions implementing man page aliases.
			    Relies on two new environment variables, BASHX_MANPATH and
				BASHX_MANPAGES. BASHX_MANPATH lists man directories and
				BASHX_MANPAGES holds a list of aliases. See the file for furhter
				details on those variables. Provides these functions:
				- list_manpages: lists aliases in BASHX_MANPAGES.
				- add_manpage: adds an alias to BASHX_MANPAGES.
				- remove_manpage: removes an aliass from BASHX_MANPAGES.
				- update_manpath: adds all man pages found in BASHX_MANPATH to
				                  BASHX_MANPAGES as aliases.
			    - bashx_man: Opens man pages, checking BASHX_MANPAGES for any
				             aliases before opening the manual.

bash_shortcuts - Contains a function to use directory-specific aliases and
                 functions. Also contains a function to move to the direcotry
                 specified in GO, and activate shortcuts there.

go - A file containing the command to move to the directory for whichever
     project I am working on. Sourced by BASH_SHORTCUTS' "go" function.

notes - Notes about bash.


