#!/bin/zsh
# Script to change font.
# Uses zsh because zsh has associative arrays.
# Bash 4 does, but most Macs don't have bash 4.

typeset -A fontopts

# reset
fontopts[clear]="\033[0m"
fontopts[reset]="\033[0m"

# colors
fontopts[black]="\033[30m"
fontopts[red]="\033[31m"
fontopts[green]="\033[32m"
fontopts[yellow]="\033[33m"
fontopts[blue]="\033[34m"
fontopts[magenta]="\033[35m"
fontopts[cyan]="\033[36m"
fontopts[white]="\033[37m"

fontopts[black2]="\033[90m"
fontopts[red2]="\033[91m"
fontopts[green2]="\033[92m"
fontopts[yellow2]="\033[93m"
fontopts[blue2]="\033[94m"
fontopts[magenta2]="\033[95m"
fontopts[cyan2]="\033[96m"
fontopts[white2]="\033[97m"

# backgrounds
fontopts[bblack]="\033[40m"
fontopts[bred]="\033[41m"
fontopts[bgreen]="\033[42m"
fontopts[byellow]="\033[43m"
fontopts[bblue]="\033[44m"
fontopts[bmagenta]="\033[45m"
fontopts[bcyan]="\033[46m"
fontopts[bwhite]="\033[47m"

fontopts[bblack2]="\033[100m"
fontopts[bred2]="\033[101m"
fontopts[bgreen2]="\033[102m"
fontopts[byellow2]="\033[103m"
fontopts[bblue2]="\033[104m"
fontopts[bmagenta2]="\033[105m"
fontopts[bcyan2]="\033[106m"
fontopts[bwhite2]="\033[107m"

# formats
fontopts[bold]="\033[1m"
fontopts[italic]="\033[3m"
fontopts[underline]="\033[4m"
fontopts[invert]="\033[7m"
fontopts[strikethrough]="\033[9m"
fontopts[deinvert]="\033[27m"


if (( $# == 0 )); then
	\builtin echo -ne ${fontopts[clear]}
	\builtin exit 0
fi

if [ -n "${@[(r)*help*]}" ]; then
	\builtin echo "Fontify the shell!\ncolors: black, red, green, yellow, blue, magenta, cyan, white\ncolors may be prefixed with b and/or suffixed with 2\nformats: bold, italic, underline, strikethrough, [de]invert\nUse 'clear', 'reset', or no arguments to return to normal."
fi

fonts=''
for arg in "$@"; do
	shift 1
	fonts+=" ${fontopts[$arg]}"
done

\builtin echo -en "$fonts"
