#!/bin/sh
# Author: Jacob Komissar
# Date: 2017-03-19
# Start an emacs server named intellij, and give it a  hidden frame.
start_server() {
	/Applications/Emacs.app/Contents/MacOS/Emacs --daemon=intellij
	emacsclient -s intellij -n -e '(load-file "/Users/jacob/.emacs.d/misc/intellij.el")'
	if [ -z "$1" ]
	then emacsclient -s intellij -n -c -e '(ns-hide-emacs t)'
	else emacsclient -s intellij -c -n "$1" >/dev/null 2>&1
	fi
}

if [ -z "$1" ] # if given no argument
then
	# bring emacs to front if server is running
	if ! emacsclient -s intellij -n -e "(ns-hide-emacs 'activate)" >/dev/null 2>&1
	then start_server "$1"
	fi
else # given argument
	# opens in existing frame if one exists
	if ! emacsclient -s intellij -n "$1" >/dev/null 2>&1
	then start_server "$1"
	fi
fi

# given argument:
#   server running:
#     frame:        open in frame
#     no frame:     ? (shouldn't matter)
#   server closed:  create frame
# no argument:
#   server running:
#     frame:        bring to front
#     no frame:     ? (shouldn't matter)
#   server closed:  create and hide frame
